import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JButton;

public class BoardPiece extends JButton implements ActionListener{
	
	public boolean active = false;
	
	public int row;
	public int col;
	
	public Board gameBoard;
	public BoardPiece [][] boardGrid;
	
	public Queue<BoardPiece> hoverQueue;
	public BoardPiece unHover[];
	
	public BoardPiece (int newRow, int newCol, Board newBoard){
		
		hoverQueue = new LinkedList<>(); 
		unHover = new BoardPiece [5];
		
		
		this.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent me) {
            	hover();
            }
            
            public void mouseExited(MouseEvent me) {
            	unHover();
            }
            
        });
		
		this.addActionListener(this);
		row = newRow;
		col = newCol;
		gameBoard = newBoard;
	
	
	}
	
	public void actionPerformed(ActionEvent e){
		gameBoard.findSelectedPiece(this, false); //find what shape is selected, the board will handle the rest.
	}
	
	public void setActive() {
		this.setBackground(Color.DARK_GRAY);
		this.setOpaque(true);
		active = true;
	}
	
	public void setHover() {
		this.setBackground(Color.orange);
		this.setOpaque(true);
	}
	
	public void addHover(BoardPiece hoverPiece) {
		hoverQueue.add(hoverPiece);
		hoverPiece.setBackground(Color.orange);
	}
	
	public void hover() { 
		
		gameBoard.findSelectedPiece(this, true);
						
		if (hoverQueue.size() > 0) {
			for(int i = 0; i < hoverQueue.size(); i++) {
				unHover[i] = hoverQueue.remove();
			}
		}			
		
	}
	
	public void unHover() {
		
		gameBoard.resetBoardColor();
	}

	

}
