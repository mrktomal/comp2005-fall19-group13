public class Main {
    public static void main(String[] args) {
        MainMenu Men = new MainMenu();
        Men.init();

    }
}
