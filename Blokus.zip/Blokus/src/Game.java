import javax.swing.SwingUtilities;

public class Game {
	
	public static Board test = new Board();

	public static void main(String[] args) {
		
		test.drawBoard();
		
	}
}
