import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GameTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testGameIntInt() {
		fail("Not yet implemented");
	}

	@Test
	void testStartGame() {
		fail("Not yet implemented");
	}

	@Test
	void testEndGame() {
		fail("Not yet implemented");
	}

	@Test
	void testPlay() {
		fail("Not yet implemented");
	}

	@Test
	void testNextPlayer() {
		fail("Not yet implemented");
	}

}
